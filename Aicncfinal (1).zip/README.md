# AICNC

Unified backend + frontend project for CNC image to G-code.

## Local test
```bash
docker compose up --build
```
Open http://localhost:8000
