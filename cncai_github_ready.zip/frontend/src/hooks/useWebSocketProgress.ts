export function useWebSocketProgress(path:string){return {events:[],connected:false,send:()=>{}}}
